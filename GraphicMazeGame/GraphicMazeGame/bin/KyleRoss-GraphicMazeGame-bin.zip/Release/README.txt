Ensure maze.txt is present with GraphicMazeGame.exe

Run GraphicMazeGame.exe